function changeClass(e){
var target=e.target;
  target.className="highlight"
}
function changeClass2(e){
  var target=e.target;
  target.className=''
}

var la=document.getElementById('list');
la.addEventListener('mouseover',changeClass,false);
la.addEventListener('mouseout',changeClass2,false);
